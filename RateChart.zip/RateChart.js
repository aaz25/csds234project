import React from 'react';
import { useTheme } from '@material-ui/core/styles';
import { LineChart, CartesianGrid, Line, XAxis, YAxis, Label, Tooltip, ResponsiveContainer } from 'recharts';
import { timeFormat } from 'd3';
import Title from './Title';

const xTickFormat = timeFormat('%m/%d');

export default function RateChart({ title, data, y, yAxisLabel = 'Rate (per 100,000)' }) {
  const theme = useTheme();
  data  = data.reverse()
  for (let i = 0; i <data.length ; i++) { 
    data[i].date = xTickFormat(data[i].date)
   }
 

   
   console.log(data)
  return ( 
    <React.Fragment>
      <Title>{title}</Title>
      <ResponsiveContainer>
      <LineChart data={data}>
                <Line type="monotone" dataKey="price" stroke= {theme.palette.text.secondary} />
                <CartesianGrid stroke="#ccc" strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis dataKey="new_cases" />
              <Line type="monotone" dataKey="new_cases" stroke={theme.palette.primary.main} dot={false} />
            </LineChart>
        </ResponsiveContainer>
    </React.Fragment>
  
  );
}